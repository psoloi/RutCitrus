# -*- coding: utf-8 -*-
"""mclog 内置错误识别规则库。

崩溃标志与 RtCli Analyzer.ProcessCrashDetectionLine 的判定保持一致
（---- Minecraft Crash Report ---- / This crash report has been saved to /
Shutting down the server / Server thread/FATAL 等）。

priority 数值越小越先匹配，先命中者作为主判定，其余命中归入“其他问题”。
java_exception / generic_error / generic_warn 三条为兜底规则（无 patterns，
由引擎在无规则命中时按“异常堆栈 / ERROR 级别 / WARN 级别”兜底触发）。
"""

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class Rule:
    rid: str
    name: str
    category_id: str
    category_name: str
    severity: str
    priority: int
    patterns: tuple
    cause: str
    suggestion: str

    def match(self, text):
        for pat in self.patterns:
            m = pat.search(text)
            if m:
                return m
        return None


def _rule(rid, name, cat, cat_name, severity, priority, patterns, cause, suggestion):
    return Rule(rid=rid, name=name, category_id=cat, category_name=cat_name,
                severity=severity, priority=priority,
                patterns=tuple(re.compile(p) for p in patterns),
                cause=cause, suggestion=suggestion)


RULES = [
    _rule('crash_report', '服务端崩溃', 'crash', '崩溃', 'FATAL', 10,
          [r'(?i)---- Minecraft Crash Report ----',
           r'(?i)This crash report has been saved to',
           r'(?i)Crash report saved',
           r'(?i)Shutting down the server',
           r'Server thread/FATAL',
           r'(?i)The server has stopped responding'],
          '服务端发生致命错误并生成/记录了崩溃信息',
          '打开 crash-reports 目录中最新报告，重点看头部 Description 与最底层 Caused by；排查最近新增或更新的模组/插件'),

    _rule('out_of_memory', '内存不足', 'memory', '内存', 'FATAL', 20,
          [r'java\.lang\.OutOfMemoryError',
           r'(?i)insufficient memory for the Java Runtime Environment',
           r'(?i)Could not reserve enough space'],
          'Java 内存耗尽，无法继续分配对象',
          '增大启动参数堆内存（如 -Xmx4G）；减少模组/插件数量；内存持续增长时排查泄漏'),

    _rule('stack_overflow', '栈溢出', 'memory', '内存', 'ERROR', 21,
          [r'java\.lang\.StackOverflowError'],
          '方法调用层级过深，通常由无限递归或循环调用引起',
          '检查相关模组/插件的递归逻辑，更新或移除问题组件'),

    _rule('server_unresponsive', '服务器无响应', 'performance', '性能', 'ERROR', 25,
          [r'(?i)A single server tick took',
           r'ServerHangWatchdog'],
          '单个游戏刻耗时过长或触发看门狗，主线程疑似卡死',
          '结合该时刻前后日志定位卡点；常见原因：大型红石机器、实体过多、模组卡顿、磁盘 IO 繁忙'),

    _rule('port_conflict', '端口占用/绑定失败', 'network', '网络', 'ERROR', 30,
          [r'(?i)Failed to bind to port',
           r'java\.net\.BindException',
           r'(?i)Address already in use',
           r'(?i)perhaps a server is already running on that port'],
          '服务端端口被占用或无法绑定，通常已有实例在运行',
          '执行 netstat -ano | findstr :<端口> 查找占用进程；或修改 server.properties 的 server-port'),

    _rule('eula_not_agreed', 'EULA 未同意', 'startup', '启动', 'ERROR', 35,
          [r'(?i)You need to agree to the EULA',
           r'(?i)eula=false'],
          'Minecraft 最终用户许可协议（EULA）未同意，服务端拒绝启动',
          '编辑服务端目录下 eula.txt，将 eula=false 改为 eula=true 后重启'),

    _rule('java_version_mismatch', 'Java 版本不匹配', 'startup', '启动', 'ERROR', 40,
          [r'UnsupportedClassVersionError',
           r'(?i)has been compiled by a more recent version of the Java Runtime',
           r'Unsupported major\.minor version',
           r'(?i)class file has wrong version'],
          '核心/模组编译所用的 Java 版本高于当前运行环境的 Java 版本',
          '升级 Java（例如 Paper 1.20.5+ 需要 Java 21），或改用与核心匹配的版本'),

    _rule('java_startup_failure', 'Java 启动失败', 'startup', '启动', 'ERROR', 45,
          [r'(?i)Error: Could not find or load main class',
           r'(?i)Unrecognized (?:VM )?option',
           r'(?i)Invalid (?:initial|maximum) heap size',
           r'(?i)Error occurred during initialization of VM',
           r'(?i)Could not create the Java Virtual Machine',
           r'(?i)A fatal exception has occurred'],
          'Java 虚拟机或启动参数存在问题，服务端进程未能启动',
          '检查启动命令与参数（内存大小、核心 jar 路径、JVM 选项）是否正确'),

    _rule('mod_dependency_missing', '模组依赖缺失', 'mod', '模组', 'ERROR', 50,
          [r'(?i)Missing or unsupported mandatory dependenc',
           r'(?i)Mod file .+ is missing mods',
           r'ModResolutionException',
           r'(?i)Mod resolution failed'],
          '模组缺少必需的前置依赖，或依赖版本不匹配',
          '按提示安装缺失的前置模组，并确保版本相互兼容'),

    _rule('mod_load_failure', '模组加载失败', 'mod', '模组', 'ERROR', 55,
          [r'ModLoadingException',
           r'(?i)Exception in mod loading',
           r'(?i)Failed to create mod instance',
           r'FormattedException: Some of your mods'],
          '模组在加载/初始化阶段抛出异常',
          '定位报错模组后更新或移除；结合完整异常堆栈与 crash-reports 排查'),

    _rule('plugin_error', '插件错误', 'plugin', '插件', 'ERROR', 60,
          [r'(?i)Error occurred while enabling',
           r'(?i)Could not load .?plugins/',
           r'(?i)Could not load plugin',
           r'(?i)generated an exception',
           r'(?i)Could not pass event',
           r'(?i)Invalid plugin\.yml',
           r'org\.bukkit\.plugin\.[A-Za-z.]*\('],
          'Bukkit/Spigot/Paper 插件在启用、事件处理或任务执行中出错',
          '更新或移除报错插件；确认其与核心版本、前置库兼容'),

    _rule('datapack_error', '数据包错误', 'datapack', '数据包', 'ERROR', 65,
          [r'(?i)Errors in currently selected datapacks',
           r'(?i)Failed to load datapacks?',
           r'(?i)datapack .+ (?:caused|failed)'],
          '数据包加载失败或包含错误',
          '检查数据包的 pack_format 与语法；临时移除后逐个排查'),

    _rule('world_chunk_error', '世界/区块错误', 'world', '世界', 'ERROR', 70,
          [r"(?i)Couldn't load chunk",
           r'(?i)corrupt\w* chunk',
           r'(?i)Failed to save chunk',
           r'(?i)Could not save the server',
           r'(?i)Wrong located chunk'],
          '世界存档或区块数据损坏/读写失败',
          '优先用备份恢复；或使用区块修复工具处理损坏区块；同时检查磁盘健康状态'),

    _rule('database_error', '数据库错误', 'database', '数据库', 'ERROR', 75,
          [r'(?i)Communications link failure',
           r'(?i)Access denied for user',
           r'(?i)Unknown database',
           r'(?i)Failed to (?:get|create) (?:a )?connection',
           r'java\.sql\.SQLException',
           r'(?i)HikariPool.*Exception'],
          '数据库连接或查询失败（常见于使用 MySQL 存储的插件）',
          '检查数据库地址/端口/账号密码与服务状态；核对插件的连接池配置'),

    _rule('disk_error', '磁盘/IO 错误', 'disk', '磁盘', 'ERROR', 80,
          [r'(?i)No space left on device',
           r'(?i)Disk quota exceeded',
           r'(?i)Read-only file system',
           r'java\.nio\.file\.(?:AccessDenied|NoSuchFile|FileSystemException)'],
          '磁盘空间不足、权限不足或文件系统异常',
          '清理磁盘空间；确认服务端进程对目录拥有读写权限'),

    _rule('config_error', '配置文件错误', 'config', '配置', 'ERROR', 85,
          [r'(?i)while parsing a block mapping',
           r'(?i)while scanning',
           r'(?i)Invalid configuration',
           r'(?i)Failed to load configuration',
           r'(?i)Could not load .+\.yml'],
          '配置文件语法或格式错误（YAML 缩进、字段类型等）',
          '按提示的行号检查对应配置文件；注意 YAML 不允许使用 Tab 缩进'),

    _rule('auth_error', '玩家认证失败', 'auth', '认证', 'WARN', 90,
          [r'(?i)Failed to verify username',
           r'(?i)invalid session'],
          '玩家正版验证失败，可能是网络问题或非正版客户端',
          '检查服务器网络与 online-mode 设置；离线环境需关闭正版验证'),

    _rule('network_error', '网络连接异常', 'network', '网络', 'WARN', 95,
          [r'(?i)Connection reset by peer',
           r'(?i)read timed out',
           r'(?i)Took too long to log in',
           r'java\.net\.SocketException',
           r'(?i)Internal Exception: java\.io\.IOException'],
          '客户端/服务端之间的网络连接中断或超时',
          '偶发可直接忽略；频繁出现请检查网络质量、防火墙与端口映射'),

    _rule('tick_overload', '服务器卡顿', 'performance', '性能', 'WARN', 100,
          [r"(?i)Can't keep up! Is the server overloaded",
           r'(?i)Running \d+\s*ms behind, skipping'],
          '服务器运行落后于预期速度，出现掉刻（TPS 下降）',
          '检查实体/红石数量，优化或移除高负载模组插件；必要时提升硬件性能'),

    _rule('java_exception', 'Java 异常', 'exception', 'Java异常', 'ERROR', 110,
          [],
          '检测到未归类的 Java 异常堆栈',
          '根据异常类名与堆栈定位来源组件；更新相关模组/插件或向作者反馈'),

    _rule('generic_error', '错误级别日志', 'other', '其他', 'ERROR', 120,
          [],
          '检测到 ERROR 级别日志，未匹配到已知错误类型',
          '结合上下文日志人工判断；必要时搜索该错误信息'),

    _rule('generic_warn', '警告级别日志', 'other', '其他', 'WARN', 130,
          [],
          '检测到 WARN 级别日志，未匹配到已知错误类型',
          '通常不影响运行；频繁出现时可关注'),
]

RULES_BY_ID = {r.rid: r for r in RULES}
ORDERED_RULES = sorted(RULES, key=lambda r: r.priority)

FALLBACK_EXCEPTION_RID = 'java_exception'
FALLBACK_ERROR_RID = 'generic_error'
FALLBACK_WARN_RID = 'generic_warn'
