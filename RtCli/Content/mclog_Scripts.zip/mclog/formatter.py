# -*- coding: utf-8 -*-
"""mclog 输出格式化：分析结果 -> 中文文本 / JSON。

文本输出会被 RtCli 的 Scripts 引擎捕获（[Python:脚本名] 前缀）并写入日志，
因此默认保持简洁、一行一要点。
"""

import json


def _clip(s, n=200):
    s = (s or '').strip()
    if len(s) <= n:
        return s
    return s[:max(0, n - 3)] + '...'


def format_text(r):
    if not r.get('is_error'):
        stats = r.get('level_stats') or {}
        stat_txt = ' / '.join('{0}×{1}'.format(k, v) for k, v in sorted(stats.items()))
        stat_txt = stat_txt or '无级别标记'
        out = ['[MC控制台错误分析] 未检测到错误 (扫描 {0} 行: {1})'.format(r.get('lines_scanned', 0), stat_txt)]
        warn = stats.get('WARN', 0)
        if warn:
            out.append('  提示: 存在 {0} 条 WARN 日志，建议留意'.format(warn))
        if r.get('event'):
            out.append('  事件: {0}'.format(r['event']))
        return '\n'.join(out)

    out = ['[MC控制台错误分析] 检测到问题 | 严重度: {0} | 分类: {1}'.format(r.get('severity', ''), r.get('category_name', ''))]
    if r.get('error_type'):
        out.append('  错误类型: {0}'.format(_clip(r['error_type'], 120)))
    if r.get('error_message'):
        out.append('  错误信息: {0}'.format(_clip(r['error_message'])))
    if r.get('cause'):
        out.append('  原因: {0}'.format(r['cause']))
    if r.get('source'):
        out.append('  来源: {0}'.format(r['source']))
    if r.get('timestamp'):
        out.append('  时间: {0}'.format(r['timestamp']))
    frames = r.get('stack_summary') or []
    if frames:
        out.append('  堆栈要点:')
        for f in frames:
            out.append('    - {0}'.format(f))
    chain = r.get('exception_chain') or []
    if len(chain) > 1:
        out.append('  异常链: {0}'.format(' <- '.join(_clip(c, 80) for c in chain[:3])))
    if r.get('suggestion'):
        out.append('  建议: {0}'.format(r['suggestion']))
    others = r.get('other_issues') or []
    if others:
        seg = '，'.join('{0}×{1}'.format(o['name'], o['count']) for o in others)
        out.append('  其他问题: {0}'.format(seg))
    if r.get('event'):
        out.append('  事件: {0}'.format(r['event']))
    return '\n'.join(out)


def format_scan_text(r):
    stats = r.get('level_stats') or {}
    stat_txt = ' / '.join('{0}×{1}'.format(k, v) for k, v in sorted(stats.items()))
    out = ['[MC日志扫描] 目标: {0}'.format(r.get('target') or '(未指定)')]
    out.append('  扫描 {0}/{1} 行 | 级别分布: {2}'.format(
        r.get('lines_scanned', 0), r.get('lines_total', 0), stat_txt or '无级别标记'))
    tr = r.get('time_range') or []
    if len(tr) == 2:
        out.append('  时间范围: {0} - {1}'.format(tr[0], tr[1]))
    issues = r.get('issues') or []
    if not issues:
        out.append('  结论: 未发现错误或警告')
        return '\n'.join(out)
    out.append('  结论: 发现 {0} 个问题，共 {1} 类'.format(r.get('issue_total', 0), len(issues)))
    for i, iss in enumerate(issues, 1):
        out.append('    {0}. [{1}] {2} ×{3}  示例: {4}'.format(
            i, iss['severity'], iss['name'], iss['count'], _clip(iss['sample'], 120)))
    top_issue = issues[0]
    out.append('  首要建议: {0}'.format(top_issue.get('suggestion', '')))
    return '\n'.join(out)


def format_json(obj):
    return json.dumps(obj, ensure_ascii=False, indent=2)
